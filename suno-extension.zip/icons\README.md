# Icons Folder

Place your extension icons here:

- `icon16.png` - 16x16 pixels
- `icon48.png` - 48x48 pixels
- `icon128.png` - 128x128 pixels

You can create icons using:
- [Canva](https://www.canva.com/)
- [Figma](https://www.figma.com/)
- [IconGenerator](https://www.favicon-generator.org/)

Or use this simple emoji-based icon generator:
- Go to: https://emoji.aranja.com/
- Type: 🎵
- Download all sizes
